# flag-status
Code to pull flag status from various websites.
