const crawl = require("./handlers/crawl");

module.exports = {
    crawl,
};
